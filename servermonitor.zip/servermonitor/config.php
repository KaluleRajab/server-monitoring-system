<?php
define('PSM_DB_HOST', 'localhost');
define('PSM_DB_PORT', '3306');
define('PSM_DB_NAME', 'skycodeit_server');
define('PSM_DB_USER', 'root');
define('PSM_DB_PASS', '');
define('PSM_DB_PREFIX', '');
define('PSM_BASE_URL', 'http://localhost/servermonitor');
define('PSM_CRON_ALLOW', array("212.48.74.29"));
define('PSM_DEBUG', true);