.. _requirements:

Requirements
============

* Web server
* MySQL database
* For PHP5: 5.6.0+
* For PHP7: 7.0.8+
* PHP cURL package
* PHP PDO mysql driver
* PHP XML package
